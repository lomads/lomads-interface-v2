import MuiButtonBase from './MuiButtonBase';
import MuiButton from './MuiButton';
import MuiOutlinedInput from './MuiOutlinedInput'
import MuiFormLabel from './MuiFormLabel'

export default {
    MuiButtonBase,
	MuiButton,
    MuiOutlinedInput,
    MuiFormLabel
};
