export default {
    defaultProps: {
        disableRipple: true,
    },
}