import React, { useEffect } from "react";
import lomadslogodark from "../../assets/svg/lomadslogodark.svg";
import GroupEnjoy from "../../assets/svg/GroupEnjoy.svg";
import { colors } from "assets/colors";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { Box, Typography } from "@mui/material"
import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme: any) => ({
	DAOsuccess: {
		display: 'flex',
		flexDirection: 'column',
		alignItems: 'center',
		justifyContent: 'flex-start',
		height: '100vh',
		textAlign: 'center'
	},
	itemsGroup: {
		marginTop: '2%',
		display: 'flex',
		alignItems: 'center',
		flexDirection: 'column'
	},
	congrats: {
		fontFamily: 'Inter, sans-serif',
		fontStyle: 'normal',
		fontWeight: '400',
		fontSize: '22px',
		lineHeight: '25px',
		textAlign: 'center',
		letterSpacing: '-0.011em',
		color: '#76808D',
		margin: '133px 0px 13.5px 0px'
	},
	header: {
		fontFamily: 'Insignia',
		fontStyle: 'normal',
		fontWeight: '400',
		fontSize: '35px',
		lineHeight: '35px',
		paddingBottom: '13px',
		textAlign: 'center',
		color: '#C94B32'
	},
	redirectText: {
		fontFamily: 'Inter, sans-serif',
		fontStyle: 'italic',
		fontWeight: '400',
		fontSize: '16px',
		lineHeight: '25px',
		textAlign: 'center',
		letterSpacing: '-0.011em',
		color: '#76808D',
		textDecoration: 'underline',
		cursor: 'pointer'
	},
	colors: {
		height: '1vw',
		width: '2.5vw',
		backgroundColor: 'aqua',
		borderRadius: '30px',
		position: 'absolute',
		top: '0',
		right: '0'
	},
	groupenjoy: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		position: 'absolute',
		bottom: '0px',
		left: '0px',
		right: '0px',
		margin: 'auto',
		width: '300px',
	}
}));

export default () => {
	const navigate = useNavigate();
	const classes = useStyles()
    const { daoURL } = useParams();
	const [searchParams, setSearchParams] = useSearchParams();

	const handleClick = async () => {
		navigate(`/${daoURL}`);
	};

	useEffect(() => {
		setTimeout(() => {
			navigate(`/${daoURL}`);
		}, 4000);
	}, []);

	return (
		<>
			<Box className={classes.DAOsuccess}>
				<Box className={classes.itemsGroup}>
					<Box>
						<img src={lomadslogodark} alt="logo" />
					</Box>
					<Box className={classes.congrats}>Well done!</Box>
					<Box className={classes.header}>Your Organisation is live</Box>
					<Box className={classes.redirectText} onClick={handleClick}>
						you will be redirected to the dashboard in a few seconds
					</Box>
					<img src={GroupEnjoy} alt="Congrats" className={classes.groupenjoy} />
				</Box>
				<img src={GroupEnjoy} alt="Congrats" className={classes.groupenjoy} />

				{colors.map((result: any) => {
					return (
						<Box
							className={classes.colors}
							sx={{
								backgroundColor: result.backgroudColor,
								left: result.left,
								right: result.right,
								top: result.top,
								bottom: result.bottom,
								transform: result.transform,
							}}
						></Box>
					);
				})}
			</Box>
		</>
	);
};
